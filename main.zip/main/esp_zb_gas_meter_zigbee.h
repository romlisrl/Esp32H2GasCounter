#include "sys/time.h"

#include "ha/esp_zigbee_ha_standard.h"
#include "zcl/esp_zigbee_zcl_power_config.h"
#include "zcl/esp_zigbee_zcl_metering.h"

// Maximum time to force a device report
#define MUST_SYNC_MINIMUM_TIME          UINT16_C(2 * 60) // 30 minutes in seconds

// time to send the device to deep sleep when Zigbee radio is on
#define TIME_TO_SLEEP_ZIGBEE_ON         pdMS_TO_TICKS(1 * 1000) // milliseconds

// time to send the device to deep sleep when Zigbee radio is on
#define TIME_TO_SLEEP_ZIGBEE_STARTING   UINT32_C(12 * 1000) // 12 seconds in milliseconds

// time to send the device to deep sleep when Zigbee radio is off
#define TIME_TO_SLEEP_ZIGBEE_OFF        pdMS_TO_TICKS(50) // milliseconds

// Maximum difference between the internal counter value and last reported counter value
#define COUNTER_REPORT_DIFF             UINT32_C(10) // in units of 0.01 m3, so 10 means 0.1 m3

// Measure current summation delivered
extern esp_zb_uint48_t current_summation_delivered;
extern bool leaving_network;

// device status and extended status
extern RTC_DATA_ATTR uint8_t device_status;
extern RTC_DATA_ATTR uint64_t device_extended_status;

// Measure instantaneous demand as int24
extern esp_zb_int24_t instantaneous_demand;

// Last report sent time
extern RTC_DATA_ATTR struct timeval last_report_sent_time;
extern RTC_DATA_ATTR uint64_t last_summation_sent;

void esp_zb_task(void *pvParameters);

#ifdef FEATURE_WRITE_COUNTER_VALUE
// Private attribute to write a value to CurrentSummationDelivered
#define GAS_METER_ATTR_SET_SUMMATION_ID       0xF000
#endif
